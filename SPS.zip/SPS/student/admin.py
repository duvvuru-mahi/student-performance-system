from django.contrib import admin
from .models import *
# Register your models here.

admin.site.register(Student)
admin.site.register(Attendance)
admin.site.register(Academic_score)
admin.site.register(Registration)
admin.site.register(Achievements)
admin.site.register(Credentials)
admin.site.register(Faculty)
admin.site.register(Gradeschema)
admin.site.register(Gradeweightage)
admin.site.register(Club)
admin.site.register(Academic_Course)
